---
sidebar: auto
---

# 支持 RSSHub

RSSHub 是采用 MIT 许可的开源项目，使用完全免费。但是随着项目规模的增长，也需要有相应的资金支持才能持续项目的维护与开发.

你可以通过下列的方法来赞助 RSSHub 的开发.

## 周期性赞助

周期性赞助可以获得额外的回报，比如更快的 GitHub 响应或者你的名字会出现在 RSSHub 的 GitHub 仓库和现在我们的官网中.

-   通过 [GitHub](https://github.com/sponsors/DIYgod) 赞助
-   通过 [Patreon](https://www.patreon.com/DIYgod) 赞助
-   通过 [爱发电](https://afdian.net/@diygod) 赞助
-   给我们发邮件联系赞助事宜: [i@diygod.me](mailto:i@diygod.me)

## 一次性赞助

我们通过以下方式接受赞助:

-   [微信支付](https://diygod.me/images/wx.jpg)
-   [支付宝](https://diygod.me/images/zfb.jpg)
-   [Paypal](https://www.paypal.me/DIYgod)
