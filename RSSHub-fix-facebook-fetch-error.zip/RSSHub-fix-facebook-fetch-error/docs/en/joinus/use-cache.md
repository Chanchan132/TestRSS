# Use Cache

Some routes require visiting several pages when generating RSS feeds, and these pages are not likely to be changed very often. In this case, caching should be used for reducing the server load and saving unnecessary traffics/calculations. Here are some scenarios and details about the use of the caching tools.

<!-- @TODO After refactoring cache class -->
