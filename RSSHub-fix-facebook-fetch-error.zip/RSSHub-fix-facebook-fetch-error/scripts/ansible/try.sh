#!/bin/bash
set -e

vagrant rsync
vagrant ssh
